import React from "react";
import LoginSystem from "./LoginSystem";

function App() {
  return <LoginSystem />;
}

export default App;
